#ifndef __hcsr04_H__
#define __hcsr04_H__

void hcsr04(void);
void TIM1init(void);
void Timer1_isr(void);
#endif
