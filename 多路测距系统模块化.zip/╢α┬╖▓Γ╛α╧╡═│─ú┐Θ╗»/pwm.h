#ifndef __pwm_H__
#define __pwm_H__
void pwm();
void Forward();
void back();
void turnright();
void turnleft();
void stop();
void Timer0Init();
#endif
