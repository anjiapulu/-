#ifndef __pwm_H__
#define __pwm_H__
void rpwm();
void lpwm();
void bpwm();
void Forward();
void back();
void turnright();
void turnleft();
void stop();
void Timer0Init();
#endif
