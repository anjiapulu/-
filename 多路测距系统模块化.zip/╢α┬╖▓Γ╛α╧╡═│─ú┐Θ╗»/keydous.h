#ifndef __keydous_H__
#define __keydous_H__

char  keydous();

#endif
